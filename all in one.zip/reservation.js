function login() {
    document.getElementById("reservationform").style.display = "none";
    document.getElementById("signupForm").style.display = "block";
  }