
function showSignupForm() {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("signupForm").style.display = "block";
  }
  
  function showLoginForm() {
    document.getElementById("signupForm").style.display = "none";
    document.getElementById("loginForm").style.display = "block";
    document.getElementById("confirmForm").style.display = "none";
  }
  
  function confirmSignup() {
    document.getElementById("signupForm").style.display = "none";
    document.getElementById("confirmForm").style.display = "block";
  }
  
  function submitForm() {
    
    var email = document.getElementById("confirmEmail").value;
    var password = document.getElementById("confirmPassword").value;

    document.getElementById("confirmForm").style.display = "none";
    document.getElementById("loginForm").style.display = "block";
  }
  function login() {
    var email = document.getElementById("loginEmail").value;
    var password = document.getElementById("loginPassword").value;

    document.getElementById("loginEmail").value = "";
    document.getElementById("loginPassword").value = "";
  }