let itemCount = 0;
let itemCountInput = document.getElementById("item-count");
let minusBtn = document.querySelector(".minus-btn");
let plusBtn = document.querySelector(".plus-btn");

minusBtn.addEventListener("click", function() {
  if (itemCount > 0) {
    itemCount--;
    itemCountInput.value = itemCount;
  }
});

plusBtn.addEventListener("click", function() {
  itemCount++;
  itemCountInput.value = itemCount;
});
