var slideIndex = 0;
showSlides();

function showSlides() {
  var slides = document.getElementsByClassName("slide");

  // Hide all slides
  for (var i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }

  // Increment the slide index
  slideIndex++;

  // If the slide index is greater than the number of slides, reset it to 1
  if (slideIndex > slides.length) {
    slideIndex = 1;
  }

  // Display the current slide
  slides[slideIndex - 1].style.display = "block";

  // Call the showSlides function again after 2 seconds (change the time as desired)
  setTimeout(showSlides, 3000);
}